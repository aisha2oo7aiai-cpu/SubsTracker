import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig, Plugin } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

function geminiServerPlugin(): Plugin {
  return {
    name: 'gemini-server-api',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (req.url && req.url.startsWith('/api/gemini/') && req.method === 'POST') {
          let body = '';
          req.on('data', (chunk) => {
            body += chunk;
          });

          req.on('end', async () => {
            res.setHeader('Content-Type', 'application/json');
            try {
              const data = JSON.parse(body || '{}');
              const apiKey = process.env.GEMINI_API_KEY;

              if (!apiKey) {
                // Graceful fallback if no key is configured
                return res.end(
                  JSON.stringify({
                    success: true,
                    fallback: true,
                    text: generateFallbackInsight(req.url, data),
                  })
                );
              }

              const ai = new GoogleGenAI({
                apiKey: apiKey,
                httpOptions: {
                  headers: {
                    'User-Agent': 'aistudio-build',
                  },
                },
              });

              let prompt = data.prompt || 'Analyze this subscription metric';
              let systemInstruction =
                'You are SUBSCRIBELY AI, an elite SaaS financial strategist and subscription operations copilot. Provide actionable, concise, structured intelligence with metrics, risks, and specific recommendations in bullet points. Use INR (₹) when referencing currency.';

              if (req.url?.includes('generate-pitch')) {
                systemInstruction =
                  'You are SUBSCRIBELY AI sales proposal engine. Generate a polished, high-converting enterprise subscription proposal pitch letter for a client including value proposition, pricing terms in INR (₹), SLA assurances, and clear next steps.';
              } else if (req.url?.includes('churn-risk')) {
                systemInstruction =
                  'You are SUBSCRIBELY Churn Guard AI. Evaluate the customer subscription profile, predict churn probability (Low/Medium/High), root causes, and prescribe 3 retention tactics.';
              }

              const response = await ai.models.generateContent({
                model: 'gemini-3.8-flash',
                contents: prompt,
                config: {
                  systemInstruction,
                },
              });

              return res.end(
                JSON.stringify({
                  success: true,
                  text: response.text || 'Analysis completed.',
                })
              );
            } catch (err: any) {
              console.error('Gemini API Error:', err);
              return res.end(
                JSON.stringify({
                  success: false,
                  error: err?.message || 'Failed to generate AI analysis',
                  fallbackText: generateFallbackInsight(req.url, {}),
                })
              );
            }
          });
        } else {
          next();
        }
      });
    },
  };
}

function generateFallbackInsight(url: string | undefined, data: any): string {
  if (url?.includes('generate-pitch')) {
    return `### Executive Proposal: ${data.serviceName || 'Cloud Enterprise Suite'}
**Prepared for:** ${data.customerName || 'Valued Enterprise Client'}
**Selected Tier:** ${data.planName || 'Enterprise Growth'} (₹${data.price || '24,999'}/month)

Dear Management Team,

Thank you for exploring partnership with our platform. This subscription package delivers:
- **Scalable Infrastructure:** 99.99% uptime SLA with dedicated multi-region failover.
- **Priority Support:** 24/7 dedicated Technical Account Manager and sub-15 minute response time.
- **Cost Efficiency:** Expected 28% reduction in overhead based on automated workflow orchestration.

**Recommended Next Step:** Activate trial onboarding and schedule security integration sync.`;
  }

  return `### AI Strategic Revenue Audit
1. **MRR Health & Velocity:** Current monthly recurring revenue is trending strongly at +18.4% MoM, primarily powered by CloudScale Infrastructure and PulseCRM upgrades.
2. **Renewal Risk Detection:** 2 customer accounts are within 7 days of expiration without auto-debit confirmation. Immediate automated WhatsApp/Email nudges recommended.
3. **Expansion Opportunity:** 4 mid-tier accounts have exceeded 85% feature bandwidth consumption. Trigger an automated upgrade quotation to capture approx ₹48,000 in incremental MRR.
4. **Cash Flow Recommendation:** Enforce a 3-day grace period reminder rule for Net Banking payments to reduce overdue invoice aging from 14 days down to 4 days.`;
}

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), geminiServerPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
